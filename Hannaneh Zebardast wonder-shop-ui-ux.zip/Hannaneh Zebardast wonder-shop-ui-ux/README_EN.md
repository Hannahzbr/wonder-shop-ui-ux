 Wonder Shop

be unique, be unforgettable

UI/UX design for an online perfume and cologne shop with a smart scent recommendation feature that matches each visitor with a fragrance based on their tastes. The whole project was designed in Figma.

![Wonder Shop Mockup](./Mockup.png)

---

 About the Project

Wonder Shop is a hypothetical project created for a User Interface Design course . The goal is to design a simple, elegant and user-friendly experience for buying perfume online. Instead of browsing hundreds of products, users answer a few simple questions about their favorite season and scents and get fragrances that suit them.

>  This repository contains the design work only. It is not a coded implementation of the website.

  Problem and Solution

Choosing a perfume online is hard because customers can't smell it before buying. Wonder Shop reduces this problem with:

- Full scent descriptions (top, middle and base notes)
- Personalized questions that lead to tailored suggestions
- User reviews and ratings
- Filters and product comparison

Key Features

| Feature | Description |
|---|---|
| 🧪 Interest detection | Users pick images (seasons, sandalwood, vanilla, lavender, jasmine, etc.) and receive suggested perfumes |
| 🔎 Filter and compare | Filter by gender, nature, season, availability and more, with side-by-side product cards |
| 🧴 Product page | High-quality image, size selection (5, 15, 45 and 100 ml), full specifications and scent notes |
| 💬 User reviews | Submit your opinion and read what other users think |
| 🛒 Cart and checkout | Shopping cart with clear steps and secure online payment |
| 👤 Login / Sign-up | Sign in with a mobile number and a verification code |
| 🏷️ Discounts | Discount badges on products and category banners (men's / women's perfumes) |

 Personas

| Name | Age | Job | Main need |
|---|---|---|---|
| Ali | 35 | Project manager | High-quality, distinctive perfumes for daily use and meetings |
| Nazanin | 28 | Fashion designer | Elegant, unique perfumes to complete her style |
| Amir | 22 | Student | Affordable perfumes with a long-lasting scent |
| Zahra | 40 | Office employee | Perfumes for different occasions and for gifts |
| Mohammad | 50 | Retired | Classic and authentic perfumes |

User Flows

1. Browse products: enter the site → see products → select a product → view details
2. Filter: enter the site → choose criteria → see filtered results → select a product
3. Personalized questions: enter the site → choose the interest detection option → answer questions → get suggestions → add to cart
4. Purchase:** view product → add to cart → review cart → confirm order → pay online
5. Rate and review: view product → submit review and rating → read other users' reviews

 Design Process

The project follows a full path from research to final design:

1. Research and documentation: project type, competitor analysis (Digikala, Irictum, physical perfume stores), personas, user stories and user flows
2. Wireframes: low-fidelity layouts for 16 screens
3. Mockup: visual design with color, imagery and typography
4. MVP: the final design of the main pages (7 pages)

 Design Principles

- Simplicity and clarity: clear navigation with "Men's" and "Women's" categories and an always-available search bar
- Visual hierarchy: clear distinction between headings, prices, discount badges and buttons
- Visual identity: a navy and gold palette for a luxurious yet calm feel, paired with high-quality product photography
- Consistency: the header, footer, cards and buttons are the same across all pages
- Persian and RTL: the interface is designed right-to-left from the ground up
- Feedback and trust: user reviews, availability and detailed scent information

 Repository Structure

```
wonder-shop-ui-ux/
├── Mockup.png        # Project mockup overview
├── MVP.pdf           # Final design of the main pages (7 pages)
├── WireFrame.pdf     # Wireframes (16 pages)
├── PDF.pdf           # Documentation (Persian): project type, competitors, personas, user stories, user flows
├── PDF_English.pdf   # English translation of the documentation
└── README.md
```

 Tools

- Figma for wireframes, mockup and MVP

 Designer

Hannaneh Zebardast
